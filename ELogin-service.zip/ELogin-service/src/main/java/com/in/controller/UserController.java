package com.in.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.in.entity.Users;
import com.in.service.UserService;


@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService service;
	
	@GetMapping("/wish")
	@PreAuthorize("hasAnyAuthority('User','Admin')")
	public String wish() {
		return "Haii";
	}
	
	@PostMapping("/register")
	public Users register(@RequestBody Users users) {
		return service.register(users);
	}
}
