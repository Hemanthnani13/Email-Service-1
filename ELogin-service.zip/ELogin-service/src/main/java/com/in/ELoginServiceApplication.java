package com.in;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ELoginServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ELoginServiceApplication.class, args);
	}

}
