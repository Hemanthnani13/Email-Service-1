package com.in.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.in.entity.Users;
import com.in.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repository;
	
	public Users register(Users users) {
		users.setPassword(new BCryptPasswordEncoder(13).encode(users.getPassword()));
		return repository.save(users);
	}

}
