package com.in.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.in.entity.Users;
import com.in.priciple.UserPrinciple;
import com.in.repository.UserRepository;

public class MyUserDetailsService implements UserDetailsService {
	
	@Autowired
	public UserRepository repository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Users users = repository.findById(username).get();
		return new UserPrinciple(users);
	}

}
